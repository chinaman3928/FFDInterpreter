class Bonus:

    def __init__(self, filler: tuple):
        """Can only be constructed using Navigator and if its pos is correct."""
        self._type, self._val = filler


    def type(self) -> int:
        return self._type

    def setVal(self, new: int) -> None:
        self._val = new

    def getWrite(self) -> bytes:
        toWrite = self._type.to_bytes(4, "little") + self._val.to_bytes(4, "little", signed = True)     ######signed
        return toWrite