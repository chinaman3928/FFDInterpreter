import navigator
import item
import ui
import util


def customTry(f: callable, exc: Exception, p1: str, changed: bool, *args, **kargs) -> (bool, "ret"):
    """ret: (whether raises, result of executing)"""
    A = '>' * 119
    ret = None
    p2 = f"{'The FFD MAY BE CHANGED' if changed else 'THE FFD IS UNCHANGED'}. The program will end on enter."
    try:
        ret = f(*args, **kargs)
    except exc as e:
        input(f"\n{A}\n>>>{p1}\n{ui.INDENT}[{type(e)}] {e}\n>>>{p2}\n{A}")
        return True, ret
    return False, ret


def execWrite(whichGame: str, pathStr: str, nav: navigator.Navigator, items: dict) -> None:
    with open(pathStr, 'wb') as wObj:
        wObj.write(nav.everythingBefore())
        print(ui.INDENT + "wrote everythingBefore")

        for key in items:
            for thisItem in items[key]:
                wObj.write(thisItem.getWrite(whichGame))
                print(ui.INDENT + f"wrote {thisItem.fullBaseName()}")

        wObj.write(nav.everythingAfter())
        print(ui.INDENT + "wrote everythingAfter")


def main() -> None:
    print(f"{'Reach me on Discord at: chinaman#3929':^119}")
    print(f"{'Join our server at: https://discord.gg/r2bZDk4C3y':^119}")
    print(f"{'Remember to back up your save!':^119}")
    print(f"{'=' * 119}\n")

    whichGame, steam_gog, pathStr, gameDirStr = ui.getInitialInfo()

    raised, nav = customTry(navigator.Navigator, OSError, "Error opening and reading file:",
                            True, whichGame, steam_gog, pathStr, gameDirStr)
    if raised: return

    raised, items = customTry(nav.finishParse, navigator.BadAssumptionError,
                              "A bad assumption was made on my end (please let me know!):", False)
    if raised: return

    for key in items:
        items[key] = [item.Item(elem) for elem in items[key]]

    ui.handleEditInterface(items, whichGame)

    if input("\nEnter CONFIRM in ALL CAPS to write edits: ") == "CONFIRM":

        raised, _ = customTry(execWrite, OSError, "Error opening and writing file:",
                              True, whichGame, pathStr, nav, items)
        if raised: return

        input("\nAll changes have been made! Hit enter to close.")
    else:
        input("\nNo changes have been made. Hit enter to close.")


if __name__ == "__main__":
    customTry(main, Exception, "Miscellaneous, unaccounted for error (please let me know!):", True)