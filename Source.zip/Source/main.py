import navigator
import item
import ui
import util
from collections import defaultdict as dd
import c


def _printCustomError(e: Exception, p1: str, changed: bool):
    """One input(), and program is expected to do no more work after."""
    A = '>' * 119
    p2 = f"{'The FFD MAY BE CHANGED (SEE ABOVE)' if changed else 'THE FFD IS UNCHANGED'}. The program will end on enter."
    input(f"\n{A}\n>>>{p1}\n{ui.INDENT}[{type(e)}] {e}\n>>>{p2}\n{A}")


def _execWrite(whichGame: str, pathStr: str, nav: navigator.Navigator, items: dict) -> None:
    if input("\nEnter CONFIRM in ALL CAPS to write edits: ") == "CONFIRM":
        with open(pathStr, 'wb') as wObj:
            wObj.write(nav.everythingBefore())
            print(ui.INDENT + "wrote everythingBefore")

            for key in items:
                for thisItem in items[key]:
                    wObj.write(thisItem.getWrite(whichGame))
                    print(ui.INDENT + f"wrote {thisItem.fullBaseName()}")

            wObj.write(nav.everythingAfter())
            print(ui.INDENT + "wrote everythingAfter")
        input("\nAll changes have been made! Hit enter to close.")
    else:
        input("\nNo changes have been made. Hit enter to close.")


def main() -> None:
    whichGame, steam_gog, pathStr, file, nonconforming = ui.getInitialInfo()

    try:
        nav = navigator.Navigator(whichGame, steam_gog, file, nonconforming)
    except navigator.BadAssumptionError as e:
        _printCustomError(e, "Bad assumption about FFD structure by me (please let me know!):", False)
    else:
        ui.handleEditInterface((nav.items(), nav.charEnchants()), whichGame)
        try:
            _execWrite(whichGame, pathStr, nav, nav.items())
        except OSError as e:
            _printCustomError(e, f"Error while attempting to write to {pathStr}:", True)


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        _printCustomError(e, "Miscellaneous, unaccounted for error (please let me know!):", True)