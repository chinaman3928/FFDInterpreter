import bonus
import enchant
import c
from util import formatStr


class Item:

    def __init__(self, filler: tuple):
        (self._urts_garbage1,
         self._baseName,
         self._fullName,	
         self._slotIndex,
         self._equipped,
         self._garbage1,
         self._grade,
         self._garbage2,
         self._armorBonus,
         self._sockets,
         self._garbage3,
         self._bonuses,
         self._ts_garbage2,
         self._ts_enchantGarbage,
         self._enchants,
         self._subItems,
         self._urts_ending) = filler


    def getWrite(self, whichGame: str) -> bytearray:
        toWrite = bytearray()

        toWrite += self._urts_garbage1

        toWrite += len(self._baseName).to_bytes(2, "little")
        toWrite += self._baseName

        toWrite += len(self._fullName).to_bytes(2, "little")
        toWrite += self._fullName

        toWrite += self._slotIndex.to_bytes(4, "little")
        toWrite += self._equipped.to_bytes(1, "little")

        toWrite += self._garbage1

        toWrite += self._grade.to_bytes(4, "little")

        toWrite += self._garbage2

        toWrite += self._armorBonus.to_bytes(4, "little")
        toWrite += self._sockets.to_bytes(4, "little")

        toWrite += self._garbage3

        toWrite += len(self._bonuses).to_bytes(4, "little")
        for elem in self._bonuses:
            toWrite += elem.getWrite()

        toWrite += self._ts_garbage2

        if whichGame == "TS":

            toWrite += len(self._subItems).to_bytes(4, "little")
            for elem in self._subItems:
                toWrite += elem.getWrite(whichGame)

            toWrite += self._ts_enchantGarbage

            #ASSUMPTION am only writing the things in self._enchants["PASSIVE"] here
            #  but also when constructing self._enchants, "USAGE" always maps to [] anyway.
            toWrite += len(self._enchants["PASSIVE"]).to_bytes(4, "little")
            for elem in self._enchants["PASSIVE"]:
                toWrite += elem.getWrite()

        else:

            for key in self._enchants:
                toWrite += len(self._enchants[key]).to_bytes(4, "little")
                for elem in self._enchants[key]:
                    toWrite += elem.getWrite()

            toWrite += len(self._subItems).to_bytes(4, "little")
            for elem in self._subItems:
                toWrite += elem.getWrite(whichGame)

        toWrite += self._urts_ending

        return toWrite


    def name(self, which: str, decode = True) -> str | bytes:
        """which: 'base' or 'full'."""
        if which == "base":
            return self._baseName.decode("utf-8") if decode else self._baseName
        if which == "full":
            return self._fullName.decode("utf-8") if decode else self._fullName

    def fullBaseName(self) -> str:
        """formatted in form {full} [{base}]"""
        return f"{formatStr(self.name('full'))} [{formatStr(self.name('base'))}]"


    def setName(self, new: bytes) -> None:
        """_fullName only"""
        self._fullName = new

    def sockets(self) -> int:
        return self._sockets

    def setSockets(self, new: int) -> None:
        self._sockets = new

    def grade(self) -> int:
        return self._grade

    def setGrade(self, new: int) -> None:
        self._grade = new

    def setNumBonuses(self, new: int) -> None:
        self._numBonuses = new

    def subItems(self) -> list["Item"]:
        return self._subItems

    def enchants(self) -> list[enchant.Enchant]:
        return self._enchants

    def _findBonus(self, type: int) -> int | None:
        """Ret: index of ._bonuses if found, else None."""
        for i, elem in enumerate(self._bonuses):
            if elem.type() == type:
                return i
        return None

    def removeBonus(self, type: int) -> None:
        """Raises ValueError if item doesn't have this bonus."""
        i = self._findBonus(type)
        if i is None:
            raise ValueError
        self._bonuses.pop(i)

    def updateBonus(self, type: int, val: int) -> None:
        """Adds if not already there, else replaces with new val."""
        i = self._findBonus(type)
        if i is None:
            self._bonuses.append(bonus.Bonus((type, val)))
        else:
            self._bonuses[i].setVal(val)

    def _findEnchant(self, type: int) -> int | None:
        """Ret: index of ._enchants if found, else None."""
        for i, elem in enumerate(self._enchants["PASSIVE"]):
            if elem.type() == type:
                return i
        return None

    def updateEnchant(self, type: int, val: int) -> None:
        """Adds if not already there, else replaces with new val."""
        #13 and 42 are +DMG_TAKEN and %DMG_TAKEN
        positive = (val >= 0) if type not in (13, 42) else (val <= 0)
        i = self._findEnchant(type)
        if i is None:
            self._enchants["PASSIVE"].append(enchant.makeNew(type, val, positive))
        else:
            self._enchants["PASSIVE"][i].setVal(val, positive)

    def removeEnchant(self, type: int) -> None:
        """Raises ValueError if item doesn't have this enchant."""
        i = self._findEnchant(type)
        if i is None:
            raise ValueError
        self._enchants["PASSIVE"].pop(i)
            
        return self._slotIndex if self._equipped else None


    def subItemContribToEnchant(self, type: int) -> int:
        total = 0
        for subitem in self._subItems:
            i = subitem._findEnchant(type)
            if i is not None:
                total += subitem._enchants["PASSIVE"][i]._value #hard use of "PASSIVE" but also elsewhere
        return total


    def tryGetEnchantVal(self, type: int) -> int | ValueError:
        i = self._findEnchant(type)
        if i is None:
            raise ValueError
        return self._enchants["PASSIVE"][i]._value


    def removeTheseSubitems(self, indexesToRem: set) -> None:
        """While also appropriately changing self's enchants."""
        if indexesToRem:
            modified : {int} = set()
            for indexToRem in indexesToRem:
                sub = self._subItems[indexToRem]
                for ench in sub.enchants()["PASSIVE"]:
                    found_in = self._findEnchant(ench.type())
                    if found_in is not None:
                        self.enchants()["PASSIVE"][found_in]._value -= ench._value
                        modified.add(found_in)

            for i in modified:
                mod = self.enchants()["PASSIVE"][i]
                positive = (mod._value >= 0) if mod.type() not in (13, 42) else (mod._value <= 0)
                if mod._value == 0:
                    del self.enchants()["PASSIVE"][i]
                elif mod._positive != positive:
                    mod._positive = positive

            self._subItems = [s for i, s in enumerate(self._subItems) if i not in indexesToRem]


#------------------------------------------------------------------------------------------------------------#
# Non-method Item-related utility functions.


def findItemByESlot(slot: int, equippeds: list[Item]) -> Item | None:
    """Left hand and left arm (shield) are collapsed into 2."""
    for elem in equippeds:
        if slot == 2:
            if elem._slotIndex in (2, 4):
                return elem
        elif elem._slotIndex == slot:
            return elem
    return None


def findItemByBaseName(baseName: int, equippeds: list[Item]) -> (Item, int):
    """Compares to the all-caps version of the name.
    Returns only the first occurrence."""
    foundItem = None
    cnt = 0
    for elem in equippeds:
        if elem.name("base").upper() == baseName:
            if foundItem is None:
                foundItem = elem
            cnt += 1

    return (foundItem, cnt)


def listOff(items: list[Item], parentNum: str = None) -> None:
    """Subitems too. If parentNum is x, then these items will have num x.1 x.2 etc."""
    num = '1' if parentNum is None else "    " + parentNum + '.1'
    for elem in items:
        print(f"{num}) {elem.fullBaseName()}")
        listOff(elem._subItems, num)
        lastDot = num.rfind('.')
        newEndNum = int(num[lastDot + 1:]) + 1
        num = num[:lastDot + 1] + str(newEndNum)


#------------------------------------------------------------------------------------------------------------#