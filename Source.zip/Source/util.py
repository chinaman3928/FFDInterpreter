def firstToAppear(search: "container", oneOf: list) -> "first":
    for elem in oneOf:
        if elem in search:
            return elem
    return None


def formatStr(string: str) -> str:
    return string.replace('\n', '').replace('\b', '')


def strInIntRange(s: str, *args, **kargs) -> bool:
    try:
        return int(s) in range(*args, **kargs)
    except ValueError:
        return False


def splits(s: str, *preds, lastsPred = None) -> bool:
    """len(preds) is the minimum number of splits"""
    s = s.split()
    if len(s) < len(preds):
        return False
    if len(s) > len(preds) and lastsPred is None:
        return False
    if any( not p(spl) for spl, p in zip(s, preds) ):
        return False
    return all( lastsPred(s[i]) for i in range(len(preds), len(s)) )


def repeatedDictKey(d: dict, key: str) -> str:
    """if ABC is in d, then goes ABC(2) —> ABC(3) —> etc"""
    if key not in d: return key
    n = 2
    key = key + f'({n})'
    while key in d:
        n += 1
        key = key[:-3] + f'({n})'
    return key


def yieldInChunks(iterable, n, filler = None):
    iterable = iter(iterable)
    try:
        while True:
            ret = []
            for _ in range(n):
                ret.append(next(iterable))
            yield ret
    except StopIteration:
        ret += [filler for _ in range(n - len(ret))]
        return ret


def zipAllTheWay(*iterables, filler = None):
    skip = [False for _ in range(len(iterables))]
    left = len(iterables)
    iterables = [iter(iterable) for iterable in iterables]
    while True:
        ret = []
        for i, iterable in enumerate(iterables):
            if skip[i]:
                ret.append(filler)
            else:
                try:
                    ret.append(next(iterable))
                except StopIteration:
                    ret.append(filler)
                    skip[i] = True
                    left -= 1
        if not left: return
        yield ret