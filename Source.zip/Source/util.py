def firstToAppear(search: "container", oneOf: list) -> "first":
    for elem in oneOf:
        if elem in search:
            return elem
    return None


def formatStr(string: str) -> str:
    return string.replace('\n', '').replace('\b', '')


def strInIntRange(s: str, *args, **kargs) -> bool:
    try:
        return int(s) in range(*args, **kargs)
    except ValueError:
        return False


def splits(s: str, *preds, lastsPred = None) -> bool:
    """len(preds) is the minimum number of splits"""
    s = s.split()
    if len(s) < len(preds):
        return False
    if len(s) > len(preds) and lastsPred is None:
        return False
    if any( not p(spl) for spl, p in zip(s, preds) ):
        return False
    return all( lastsPred(s[i]) for i in range(len(preds), len(s)) )
