MAX_HOTKEYS = 12    #seems same for OG and TS
CONTEXT_TIPS = 19   #seems same for OG and TS
JOURNAL_STATISTICS = 16 #code says 17, but why only 16 in the save/game?
                        #gog_steam assumed to have 17
DAMAGE_TYPES = 8
SKILLS = 15
MAGIC_SPHERES = 3
MAX_SPELLS_PER_SPHERE = 6
ACTIVATION_TYPES = 2

#TODO heroic?
BONUSES = {"PIERCE": 0,
            "SLASH": 1,
            "CRUSH": 2,
            "MAGIC": 3,
            "FIRE": 4,
            "ICE": 5,
            "ELECTRIC": 6,
            "UNDEAD": 7}

ENCHANTS_STR_INT = {"+STR": 0,
            "+DEX": 1,
            "+VIT": 2,
            "+MAG": 3,
            "+MANA": 4,
            "+HP": 5,
            "+STAMINA": 6,
            "MANA_REGEN": 7,
            "HP_REGEN": 8,
            "STAMINA_REGEN": 9,
            "+DEFENSE": 10,
            "+ATTACK": 11,
            "+DMG": 12,
            "+DMG_TAKEN": 13,
            "KNOCKBACK": 14,
            "SSWORD": 15,
            "SCLUB": 16,
            "SHAMMER": 17,
            "SAXE": 18,
            "SSPEAR": 19,
            "SSTAFF": 20,
            "SPOLEARM": 21,
            "SBOW": 22,
            "SCROSSBOW": 23,
            "SCRIT": 24,
            "SDUAL": 25,
            "SSHIELD": 26,
            "SATTACKMAG": 27,
            "SDEFENSEMAG": 28,
            "SCHARMMAG": 29,
            "%STR": 30,
            "%DEX": 31,
            "%VIT": 32,
            "%MAG": 33,
            "%MANA": 34,
            "%HP": 35,
            "%STAMINA": 36,
            "%SPEED": 37,
            "%ATTACKSPEED": 38,
            "%DEFENSE": 39,
            "%ATTACK": 40,
            "%DMG": 41,
            "%DMG_TAKEN": 42,
            "%MAGIC_DROP": 43,
            "%GOLD_DROP": 44,
            "%CAST_SPEED": 45,
            "%LIFE_STEAL": 46,
            "%MANA_STEAL": 47,
            "%DMG_REFLECT": 48,
            "%BLOCK": 49,
            "%REDUCED_REQ": 50,
            "%RES_PIERCE": 51,
            "%RES_SLASH": 52,
            "%RES_CRUSH": 53,
            "%RES_MAGIC": 54,
            "%RES_FIRE": 55,
            "%RES_ICE": 56,
            "%RES_ELECTRIC": 57}

ENCHANTS_INT_STR = {val : key for key, val in ENCHANTS_STR_INT.items()}

ENCHANT_TABLE = [
                    " STATS1 / STATS2 / RESIST / SKILL1 / SKILL2 / OTHER1 / OTHER2 ",
                    "%STR/+STR/%DMG_TAKEN/SSWORD/SCROSSBOW/%SPEED/KNOCKBACK",
                    "%DEX/+DEX/%RES_PIERCE/SCLUB/SCRIT/%ATTACKSPEED/HP_REGEN",
                    "%VIT/+VIT/%RES_SLASH/SHAMMER/SDUAL/%CAST_SPEED/MANA_REGEN",
                    "%MAG/+MAG/%RES_CRUSH/SAXE/SSHIELD/%LIFE_STEAL/STAMINA_REGEN",
                    "%DMG/+DMG/%RES_MAGIC/SSPEAR/SATTACKMAG/%MANA_STEAL/%REDUCED_REQ",
                    "%ATTACK/+ATTACK/%RES_FIRE/SSTAFF/SDEFENSEMAG/%BLOCK/%MAGIC_DROP",
                    "%DEFENSE/+DEFENSE/%RES_ICE/SPOLEARM/SCHARMMAG/%DMG_REFLECT/%GOLD_DROP",
                    "%HP/+HP/%RES_ELECTRIC/SBOW/ / / ",
                    "%STAMINA/+STAMINA/+DMG_TAKEN/ / / / ",
                    "%MANA/+MANA/ / / / / "
                    ]

OGUR_SHORTCUT_SLOT = {
        "HEAD": 0,
        "NECK": 6,
        "RHAND": 3,
        "LHAND": 2, #shield included
        "CHEST": 1,
        "GLOVES": 5,
        "RRING": 9,
        "LRING": 8,
        "BELT": 10,
        "BOOTS": 7
        }

TS_SHORTCUT_SLOT = dict(OGUR_SHORTCUT_SLOT, CLOAK = 11, EAR = 12)