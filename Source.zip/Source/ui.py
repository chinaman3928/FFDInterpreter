import item
import c
import util
from re import findall
from collections import defaultdict as dd
import enchant

from navigator import ts_findNonconforming


INDENT = "    " #four spaces


#-------------------------------------------------------------------------------------#
# Getting initial info.

def getInitialInfo() -> (str, bool, str, bytes, set | None):
    """Prompts until valid / computes: whichGame, steam_gog, pathStr, file, nonconforming."""
    print(f"{'Reach me on Discord at: chinaman#3928':^119}")
    print(f"{'Join our server at: https://discord.gg/r2bZDk4C3y':^119}")
    print(f"{'Remember to back up your save!':^119}")
    print(f"{'=' * 119}\n")

    whichGame = input("Which game is this for? OG UR TS: ").strip().upper()
    while whichGame not in {"OG", "UR", "TS"}:
        whichGame = input(INDENT + "Try again: ").strip().upper()

    steam_gog = input("\nIs this for Steam or GOG (not Wildtangent)? ('y' for yes): ").upper().strip() == 'Y'

    prompt = "\nEnter full path of .FFD file: "
    while True:
        pathStr = input(prompt).strip()
        try:
            with open(pathStr, 'rb') as rObj:
                file = rObj.read()
        except OSError:
            prompt = f"{INDENT}Try again: "
        else:
            break

    if whichGame == "TS":
        prompt = "\nEnter full path of the TS folder (the one with the ITEM subfolder): "
        while True:
            gameDirStr = input(prompt).strip()
            try:
                nonconforming = ts_findNonconforming(gameDirStr)
            except OSError:
                prompt = f"{INDENT}Try again: "
            else:
                break
    else:
        gameDirStr, nonconforming = None, None

    return whichGame, steam_gog, pathStr, file, nonconforming


#-------------------------------------------------------------------------------------#
# Choosing the item


def _printItemChoices(whichGame: str) -> None:
    print("\nWhat item do you want to edit? Options:")
    scs = ', '.join(sc for sc in (c.OGUR_SHORTCUT_SLOT if whichGame in {"OG", "UR"} else c.TS_SHORTCUT_SLOT))
    print(INDENT + f"—Shortcuts for equipped items: {{{scs}}}")
    print(INDENT + "—Base unenchanted name of your item — grade isn't included (ex. Legendary Cheese Sword)")
    print(INDENT + "—ALL to bring up a list of all your items and then choose from the list")
    print(INDENT + "—END if you're done")


def _handleEShortcut(choice: str, items: dict, whichGame: str) -> item.Item | None:
    slot = (c.OGUR_SHORTCUT_SLOT if whichGame in {"OG", "UR"} else c.TS_SHORTCUT_SLOT)[choice]
    theItem = item.findItemByESlot(slot, items["EQUIPPED"])
    if theItem is None:
        print("\nYou don't have an item in that slot!")
    return theItem


def _handleAll(items: dict) -> item.Item | None:
    print("\n[E]QUIPPED")
    item.listOff(items["EQUIPPED"])

    print("\n[I]NVENTORY")
    item.listOff(items["INVENTORY"])

    prompt = "\nPick your item (ex. 'E 3.2.1' or 'I 17') or BACK to item select: "
    while True:
        the_input = input(prompt).strip().upper()
        if the_input == "BACK":
            print("Okay, back to item select.")
            return

        try:
            spec, nums = the_input.split()
            assert spec in ('E', 'I')

            nums = [int(num) for num in nums.split('.')]
            assert spec in ('E', 'I') and all([num > 0 for num in nums])
            theItem = items["EQUIPPED" if spec == 'E' else "INVENTORY"][nums[0] - 1]
            for num in nums[1:]:
                theItem = theItem.subItems()[num - 1]
            return theItem
        except (AssertionError, ValueError, IndexError):
            prompt = INDENT + "Invalid input, try again: "


def _handleBaseName(items: dict, choice: str) -> item.Item | None:
    theItem, cnt = item.findItemByBaseName(choice, items["EQUIPPED"] + items["INVENTORY"])
    if theItem is None:
        return None
    if cnt > 1:
        print(f"\nYou have {cnt} of these, but I'll just go with one of them.")
    return theItem


def _confirmItemChoice(theItem: item.Item) -> bool:
    print(f"\nLooks like you chose {theItem.fullBaseName()}")
    if input("Continue with this? ('y' for yes): ").strip().upper() == 'Y':
        return True
    print("Okay, back to item select.")
    return False


def _getItemChoice(items: dict, whichGame: str) -> item.Item | None:
    """Ret: None if END."""
    skipPrintItemChoices = False
    prompt = "Enter your choice: "
    while True:
        if not skipPrintItemChoices:
            _printItemChoices(whichGame)
        choice = input(prompt).strip().upper()

        if choice in (c.OGUR_SHORTCUT_SLOT if whichGame in {"OG", "UR"} else c.TS_SHORTCUT_SLOT):
            theItem = _handleEShortcut(choice, items, whichGame)
        elif choice == "ALL":
            theItem = _handleAll(items)
        elif choice == "END":
            return None
        else: #then assume entering base name
            theItem = _handleBaseName(items, choice)
            if theItem is None: #then invalid input and ask to retry
                skipPrintItemChoices = True
                prompt = INDENT + "Invalid input, try again: "
                continue

        if theItem is not None and _confirmItemChoice(theItem):
            return theItem
        
        skipPrintItemChoices = False
        prompt = "Enter your choice: "


#-------------------------------------------------------------------------------------#
# Choosing the edits


def _printActionChoices(fullName: str) -> None:
    print('\n' + fullName)
    print(INDENT + "—BACK to item select")
    print(INDENT + "—NAME (bold purpletext + newlines)")
    print(INDENT + "—ENCHANT to edit enchants")
    print(INDENT + "—BONUS to edit damage bonuses")
    print(INDENT + "—GRADE [grade] where [N]ormal, [S]uperior, [E]xceptional, [F]lawless")
    print(INDENT + "—SOCKETS to edit sockets and subitems")


def _printEnchantTable() -> None:
    print()
    indivs = c.ENCHANT_TABLE[0].split('/')
    thisRow = f"{indivs[0]:=^16}"
    for indiv in indivs[1:]:
        thisRow += f"|{indiv:=^16}"

    print(thisRow)

    for row in c.ENCHANT_TABLE[1:]:
        indivs = row.split('/')
        thisRow = f"{indivs[0]:^16}"
        for indiv in indivs[1:]:
            thisRow += f"|{indiv:^16}"
        print(thisRow)


def _printCumEnchants(items_charEnchants: tuple, whichGame: str) -> None:
    items, charEnchants = items_charEnchants
    d = dd(lambda: [0, dict()])

    for key, source in ( ("PASSIVE", "INTRINSIC"), ("USAGE", "SPELL") ):
        for ench in charEnchants[key]:
            V = d[c.ENCHANTS_INT_STR[ench.type()]]
            V[0] += ench.value()
            V[1][util.repeatedDictKey(V[1], source)] = ench.value()

    for eitem in items["EQUIPPED"]:
        for ench in eitem.enchants()["PASSIVE"]:
            V = d[c.ENCHANTS_INT_STR[ench.type()]] if whichGame in {"OG", "UR"} else d[c.ENCHANTS_GAMESTR_STR[ench.ts_typeStr()]]
            V[0] += ench.value()
            V[1][util.repeatedDictKey(V[1], eitem.name("base"))] = ench.value()

    print()
    for chunk in util.yieldInChunks(sorted(d.items(), key = lambda x: -x[1][0]), 3):
        print('|'.join(f"{f' {V[0]} ({V[1][0]}) ':=^39}" if V is not None else ('='*39) for V in chunk))
        breakdowns = [sorted(V[1][1].items(), key = lambda x: -x[1]) for V in chunk]
        print(f"{' '*39}|{' '*39}|{' '*39}")
        for row in util.zipAllTheWay(*breakdowns):
            print('|'.join(f"{f' {name_contrib[0]} ({name_contrib[1]}) ':^39}" if name_contrib is not None else (' '*39) for name_contrib in row))
        print(f"{' '*39}|{' '*39}|{' '*39}")
        
    
def _handleEnchant(theItem: item.Item) -> None:
    """Prompts until useable input, so always returns None."""
    _printEnchantTable()
    print("\nEnter as many as you want in format '[enchant] [value / '-' to remove]', or BACK to stop.")
    prompt = "Enter your choice: "
    while True:
        choice = input(prompt).strip().upper()
        if choice == "BACK":
            return

        try:
            p1, p2 = choice.split()
            if p1 in c.ENCHANTS_STR_INT:

                if p2 == '-':
                    if theItem._findEnchant(c.ENCHANTS_STR_INT[p1]) is None:
                        raise ValueError
                    subContrib = theItem.subItemContribToEnchant(c.ENCHANTS_STR_INT[p1])
                    if subContrib == 0:
                        theItem.removeEnchant(c.ENCHANTS_STR_INT[p1])
                    else:
                        theItem.updateEnchant(c.ENCHANTS_STR_INT[p1], subContrib)

                else:
                    theItem.updateEnchant(c.ENCHANTS_STR_INT[p1], int(p2))
                prompt = "Got it, any more?: "
        except ValueError:
            prompt = INDENT + "Invalid input, try again: "


def _handleBonus(theItem: item.Item, BONUSES) -> None:
    """Prompts until useable input, so always returns None."""
    print(f"\n{', '.join(BONUSES)}")
    print("Enter as many as you want in format '[bonus] [value / '-' to remove]', or BACK to stop.")
    prompt = "Enter your choice: "
    while True:
        choice = input(prompt).strip().upper()
        if choice == "BACK":
            return

        try:
            p1, p2 = choice.split()
            assert p1 in BONUSES

            if p2 == '-':
                theItem.removeBonus(BONUSES[p1]) #raises ValueError if not exist
            else:
                theItem.updateBonus(BONUSES[p1], int(p2))
            prompt = "Got it, any more?: "
        except (ValueError, AssertionError): #can't split into two | invalid p1 | bad remove
            prompt = INDENT + "Invalid input, try again: "


def _handleGrade(theItem: item.Item, p2: str) -> None:
    grades = {'N': 0, 'S': 1, 'E': 2, 'F': 3}
    gradeStrs = {0: 'Normal', 1: 'Superior', 2: 'Exceptional', 3: 'Flawless',
                 'N': 'Normal', 'S': 'Superior', 'E': 'Exceptional', 'F': 'Flawless'}
    gradeAsBytes = {'N': b'', 'S': b"\x08Superior \x08", 'E': b"\x08Exceptional \x08", 'F': b"\x08Flawless \x08"}
                    
    old = theItem.grade()
    theItem.setGrade(grades[p2])
                    
    encodedName = theItem.name("full", decode = False)

    firstAppear = util.firstToAppear(encodedName, set(gradeAsBytes.values()) - {b''})
    if firstAppear != None:
        theItem.setName(encodedName.replace(firstAppear, gradeAsBytes[p2]))

    elif encodedName.find(b"'s \x10") != -1:
        i = encodedName.find(b"'s \x10")
        encodedName[i + 4 : i + 4] = gradeAsBytes[p2]
        theItem.setName(encodedName)

    else: #add onto the front
        theItem.setName(gradeAsBytes[p2] + encodedName)

    print(f"Got it. Changed from {gradeStrs[old]} —> {gradeStrs[p2]}")


def _handleFullName(theItem: item.Item) -> None:
    old = util.formatStr(theItem.name("full"))
    new = ''
    prompt = "\nEnter the new name or all-caps BACK ('\\n' —> newline, '\\bTEXT\\b' —> bolded TEXT, '\\\\' —> backslash): "
    while new != "BACK" and (not new or len(findall(r'(?<!\\)\\b', new)) % 2 == 1):
        new = input(prompt)
        prompt = INDENT + "Invalid name, try again: "

    if new == "BACK":
        print("Okay, item name unchanged.")
        return

    asLst = list(new)
    i, boldsFound = 0, 0
    while i < len(asLst):
        if asLst[i : i + 2] == list('\\n'):
            if (i - 1 > 0 and asLst[i - 1] == ' ') or (i+ 2 < len(asLst) and asLst[i + 2] == ' '):
                asLst[i : i + 2] = '\n' 
                i += 1
            else: 
                asLst[i : i + 2] = ' \n'
                i += 2

        elif asLst[i : i + 2] == list('\\b'):
            asLst[i : i + 2] = '\b'
            i += 1
            boldsFound += 1

        elif asLst[i : i + 2] == list('\\\\'):
            asLst[i : i + 2] = '\\'
            i += 1

        else:
            i += 1

    theItem.setName(''.join(asLst).encode("utf-8"))
    print(f"Got it. {old} —> {util.formatStr(theItem.name('full'))}")


def _handleSockets(theItem: item.Item) -> None:
    old = theItem.sockets()
    print()
    item.listOff([theItem])
    print(f"(This item has {old} sockets.)\n")

    print("Change number of sockets from 0-20 (ex. 'NUM 10') or remove existing subitems (ex. '- 1 2 3') or BACK to stop.")
    prompt = "Enter your choice: "
    while True:
        the_input = input(prompt).strip().upper()
        if the_input == "BACK":
            print("Okay, item unchanged.")
            return

        try:
            p1, *p2 = the_input.split()
        except ValueError:     #can't unpack properly
            prompt = INDENT + "Invalid input, try again: "
        else:
            
            if p1 == "NUM" and len(p2) == 1 and util.strInIntRange(p2[0], 21):
                new = int(p2[0])
                if new < len(theItem.subItems()):
                    numRem = len(theItem.subItems()) - new
                    if input(f"\n{numRem} subitems will be removed, but you can choose which. Enter 'y' to continue: ").strip().upper() == 'Y':
                        prompt = f"Enter <= {numRem} subitems to remove (ex. '1 2 3'), and the remaining will get chopped off the end: "
                        while True:
                            indexesToRem = set(input(prompt).upper().strip().split())
                            if len(indexesToRem) <= numRem and all(util.strInIntRange(i, 1, len(theItem.subItems()) + 1) for i in indexesToRem):
                                indexesToRem = {int(i) - 1 for i in indexesToRem}
                                break
                            prompt = INDENT + "Invalid input, try again: "

                        i = len(theItem.subItems()) - 1
                        while len(indexesToRem) < numRem:
                            if i not in indexesToRem:
                                indexesToRem.add(i)
                            i -= 1

                        print(f"\nRemoving these {numRem} subitems:")
                        for i in sorted(indexesToRem):
                            print(INDENT + f"{i+1}) {theItem.subItems()[i].fullBaseName()}")

                        theItem.removeTheseSubitems(indexesToRem)

                    else:
                        print("Okay, no change has been made.")
                        return

                theItem.setSockets(new)
                print(f"Okay, sockets changed from {old} —> {new}.")
                return

            elif p1 == "-" and p2 and all(util.strInIntRange(i, 1, len(theItem.subItems()) + 1) for i in p2):
                indexesToRem = {int(i) - 1 for i in p2}

                print(f"\nGot it. Removed these {len(indexesToRem)} subitems:")
                for i in sorted(indexesToRem):
                    print(INDENT + f"{i+1}) {theItem.subItems()[i].fullBaseName()}")

                theItem.removeTheseSubitems(indexesToRem)
                return

            else:
                prompt = INDENT + "Invalid input, try again: "


def handleEditInterface(items_charEnchants: tuple, whichGame: str) -> None:
    _printCumEnchants(items_charEnchants, whichGame)

    while True:
        theItem = _getItemChoice(items_charEnchants[0], whichGame)
        if theItem is None:
            return

        skipPrintActionChoices = False
        prompt = "Enter your choice: "
        while True:
            if not skipPrintActionChoices:
                _printActionChoices(f"{f' {theItem.fullBaseName()} ':=^119}")

            choice = input(prompt).strip().upper()
            if choice == "BACK":
                break
            elif choice == "NAME":
                _handleFullName(theItem)
            elif choice == "ENCHANT":
                _handleEnchant(theItem)
            elif choice == "BONUS":
                _handleBonus(theItem, c.BONUSES if whichGame == "OG" else c.BONUSES | {"HEROIC": 8})
            elif choice == "SOCKETS":
                _handleSockets(theItem)
            elif util.splits(choice, lambda x: x == "GRADE", lambda x: x in set("NSEF")):
                _handleGrade(theItem, choice.split()[1])
            else:
                skipPrintActionChoices = True
                prompt = INDENT + "Invalid input, try again: "
                continue
            skipPrintActionChoices = False
            prompt = "Enter your choice: "