import struct
import c

#hi yes note to self: sizeof( D3DXVECTOR3 ) + sizeof( D3DXMATRIX ) = 76
#new note to self: sizeof( D3DXVECTOR3 ) + sizeof( D3DXVECTOR3 ) + sizeof( D3DXMATRIX ) = 88 i think


class BadAssumptionError(Exception):
    pass


class Navigator:

    def __init__(self, whichGame: str, steam_gog: bool, pathStr: str, gameDirStr: str | None):
        """Reads entire FFD and, if TS, finds nonconforming.
        You must also call .finishParse() right after this."""
        self._whichGame, self._steam_gog = whichGame, steam_gog

        with open(pathStr, 'rb') as rObj:
            self._file = rObj.read()

        # Items that don't conform are those that have 0000 2000 [0000] x000 instead of just 2000 0000 [] x0000
        # where x is the number of (passive?) enchants. I also guess that this is a property iff the item chunk
        # ends with 00 instead of just 000000. ALTHOUGH of course these bytes are not gauranteed to be as shown (but they seem to be).
        if whichGame == "TS":
            self._nonconforming = set()
            self._findNonconforming(gameDirStr)
            
        self._pos = 0
        self._garbageUpTo = None #up to and including last btye of NUMBER OF ITEMS
        self._garbageResume = None

    def _findNonconforming(self, gameDirStr: str) -> None:
        """Adds to _nonconforming all base item names that don't conform as bytes.
        Called only in __init__() only for TS."""

        # ASSUMPTION this is just a guess for what is nonconforming
        NONCONFOM = {"POTION",
	                "SCROLL",
	                "BOOK",
	                "SPELL",
	                "PETFOOD",
                    "TAROT"}

        for ext in (r"\ITEMS\en-US\items.dat", r"\REALMS\Goldshare\ITEMS\en-us\items.dat", r"\REALMS\URGold\ITEMS\en-us\items.dat"):
            thisPath = gameDirStr + ext
            startsEnds = []
            start, end = None, None
            with open(thisPath) as rObj:
                lines = rObj.read().splitlines()
            for i, line in enumerate(lines):
                if line.startswith("[ITEM]"):
                    start = i
                elif line.startswith("[/ITEM]"):
                    end = i
                if start is not None and end is not None:
                    startsEnds.append((start, end))
                    start, end = None, None

            for start, end in startsEnds:
                the_name, the_type = None, None
                for i in range(start + 1, end + 1 - 1):
                    if lines[i].startswith("<NAME>:"):
                        the_name = lines[i][7:]
                    elif lines[i].startswith("<TYPE>:"):
                        the_type = lines[i][7:]
                    if (the_name is not None and the_type is not None) or i == end - 1:
                        if the_type in NONCONFOM:
                            self._nonconforming.add(bytes(the_name, encoding = "utf-8"))
                            the_name, the_type = None, None
                        break

    def finishParse(self) -> dict["EQUIPPED/INVENTORY"]:
        numItems = self._goTilNumItems()

        items = {"EQUIPPED": [], "INVENTORY": []}

        for n in range(numItems):
            filler = self._parseItem()
            items["EQUIPPED" if filler[4] else "INVENTORY"].append(filler) #index 4 is equipped

        self._garbageResume = self._pos

        return items

    def _goTilNumItems(self) -> int:
        """Ret: number of items"""

        if self._whichGame == "OG":
            self.move(7)
        else:       #UR CHANGE
            self.move(15)

        for n in range(c.MAX_HOTKEYS):
            self.passThisString()

        self.move(c.CONTEXT_TIPS)   #funny how all games have the same num of these tips
        
        if self._whichGame in {"UR", "TS"}:     #UR CHANGE
            self.move(4)

        self.passThisString()
        self.passThisString()

        self.move(5)

        self.move((c.JOURNAL_STATISTICS + (1 if self._steam_gog else 0)) * 4)

        self.move(8 * 4)

        # ASSUMPTION
        if self._steam_gog and self._whichGame in {"UR", "TS"}:
            self.move(8)

        #character name is here
        self.passThisString()
        self.passThisString()

        self.move(191)
        #we should now just have passed m_Unique (line 11860)

        self.move(c.DAMAGE_TYPES * 4)  #SCIENCE in UR and probs TS the enum used here is still 8, same as OG
        self.move(c.SKILLS * 4)

        for n1 in range(c.MAGIC_SPHERES):
            for n2 in range(c.MAX_SPELLS_PER_SPHERE):
                self.passThisString()

        self.passThisString()

        self.move(44)
        #we should now just have passed m_Gold (line 11906)


        for n1 in range(c.ACTIVATION_TYPES):
            numEffects = self.readInt()
            for n2 in range(numEffects):
                self.passThisString()
                self.passThisString()
                self.move(78)

        numItems = self.readInt() 
        self._garbageUpTo = self._pos

        return numItems
    
    def _parseBonus(self) -> tuple:
        type = self.readInt()
        val = self.readInt()

        return (type, val)

    def _parseEnchant(self) -> tuple:

        urts_garbage1 = self.read(4) if self._whichGame == "TS" else b''

        name = self.passThisString(read = True)
        message = self.passThisString(read = True)

        exclusive = bool(self.readInt(1))
        type = self.readInt()
        damageType = self.readInt()
        positive = bool(self.readInt(1))
        activation = self.readInt()
        chanceOfSuccess = self.readInt()
        chanceOfSuccessBonus = self.readInt()
        chanceOfSuccessBonusPercent = self.readInt()
        duration = self.readInt()
        durationBonus = self.readInt() #stores it as a positive int but in the code a negative constant is used
        durationBonusPercent = self.readInt()
        value = self.readFloat()
        valueBonus = self.readFloat()
        valueBonusPercent = self.readFloat()
        value2 = self.readFloat()
        value2Bonus = self.readFloat()
        value2BonusPercent = self.readFloat()
        value3 = self.readFloat()
        value3Bonus = self.readFloat()
        value3BonusPercent = self.readFloat()
        priceMultiplier = self.readFloat()

        if self._whichGame == "TS":
            ts_beforeTypeStr = self.read(2)
            if ts_beforeTypeStr != b'\x00\x00':
                raise BadAssumptionError(f"Assumed 00 before enchant type string, got {weirdTwo}. ({self._pos - 2})")
            ts_typeStr = self.passThisString(read = True)
        else:
            ts_beforeTypeStr, ts_typeStr = b'', b''

        return (urts_garbage1,
                name,
                message,
                exclusive,
                type,
                damageType,
                positive,
                activation,
                chanceOfSuccess,
                chanceOfSuccessBonus,
                chanceOfSuccessBonusPercent,
                duration,
                durationBonus,
                durationBonusPercent,
                value,
                valueBonus,
                valueBonusPercent,
                value2,
                value2Bonus,
                value2BonusPercent,
                value3,
                value3Bonus,
                value3BonusPercent,
                priceMultiplier,
                ts_beforeTypeStr,
                ts_typeStr)

    def _parseItem(self) -> tuple:
        
        urts_garbage1 = self.read(4) if self._whichGame in {"UR", "TS"} else b''

        baseName = self.passThisString(read = True)

        fullName = self.passThisString(read = True)

        #cherry pick which i think are interesting

        slotIndex = self.readInt()

        equipped = bool(self.readInt(1))

        garbage1 = self.read(85)

        grade = self.readInt()

        garbage2 = self.read(3)

        armorBonus = self.readInt()

        sockets = self.readInt()

        #damage bonuses

        garbage3 = self.read(7)

        numBonuses = self.readInt()
        bonuses = []
        for n in range(numBonuses):
            bonuses.append(self._parseBonus())

        ts_garbage2 = self.read(8) if self._whichGame == "TS" else b''

        if self._whichGame in {"OG", "UR"}:
            #enchants
            enchants = {"PASSIVE": [], "USAGE": []}
            for key in enchants:
                numEnchants = self.readInt()
                for n in range(numEnchants):
                    enchants[key].append(self._parseEnchant())

            #nested sub items
            numSubItems = self.readInt()
            subItems = []
            for n in range(numSubItems):
                subItems.append(self._parseItem())

            #m_heroID (4) and m_HEROID.c_str() (1)

            ts_enchantGarbage, urts_ending = b'', b'' if self._whichGame == "OG" else self.read(4)

            if self._whichGame == "UR" and urts_ending !=  b'\x00\x00\x00\x00':
                raise BadAssumptionError(f"Assumed 0000 at end but got {urts_ending} ({self._pos - 4})")

        else:
            #nested sub items
            numSubItems = self.readInt()
            subItems = []
            for n in range(numSubItems):
                subItems.append(self._parseItem())

            #enchants

            ### ASSUMPTION that only one enchant key ("PASSIVE")

            if baseName in self._nonconforming:
                ts_enchantGarbage = self.read(12)
                if ts_enchantGarbage != b'\x00\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00':
                    raise BadAssumptionError(f"Assumed 0000 2000 0000 in enchants but got {ts_enchantGarbage}. ({self._pos - 12})")
            else:
                ts_enchantGarbage = self.read(8)
                if ts_enchantGarbage != b'\x00\x00\x00\x00\x02\x00\x00\x00':
                    raise BadAssumptionError(f"Assumed 0000 2000 in enchants but got {ts_enchantGarbage}. ({self._pos - 8})")

            enchants = {"PASSIVE": []}
            for key in enchants:
                numEnchants = self.readInt()
                for n in range(numEnchants):
                    enchants[key].append(self._parseEnchant())

            enchants["USAGE"] = []

            expectedZeroes = 2 if baseName in self._nonconforming else 6
            urts_ending = self.read(expectedZeroes)

            if urts_ending != b'\x00' * expectedZeroes:
                raise BadAssumptionError(f"Assumed {expectedZeroes} zeroes at the end but got {urts_ending}. ({self._pos - expectedZeroes})")

        return (urts_garbage1,
                baseName,
                fullName, 
                slotIndex, 
                equipped, 
                garbage1, 
                grade, 
                garbage2, 
                armorBonus, 
                sockets, 
                garbage3,
                bonuses, 
                ts_garbage2,
                ts_enchantGarbage,
                enchants,
                subItems,
                urts_ending)


    #------------------------------------------------------------------------------------------------------------#
    # Methods for navigation and reading.

    def move(self, by: int, rel = True) -> int:
        if rel:
            self._pos += by
        else:
            self._pos = by
        return self._pos

    def read(self, size: int) -> bytes:
        toRet = self._file[self._pos:self._pos + size]
        self._pos += size
        return toRet

    def passThisString(self, size: int = 2, read: bool = False) -> bytes | None:
        """Assumes pos is at the first byte of the string size.
        Ret: BYTES not string."""
        length = int.from_bytes(self.read(size), "little")

        if read:
            return self.read(length)
            
        self.move(length)

    def readInt(self, size = 4) -> int:
        return int.from_bytes(self.read(size), "little")

    def readFloat(self, size = 4) -> float:
        return struct.unpack('f', self.read(size))[0]

    def everythingBefore(self) -> bytes:
        return self._file[:self._garbageUpTo]

    def everythingAfter(self) -> bytes:
        return self._file[self._garbageResume:]