import struct
import c

from item import Item
from bonus import Bonus
from enchant import Enchant

#hi yes note to self: sizeof( D3DXVECTOR3 ) + sizeof( D3DXMATRIX ) = 76
#new note to self: sizeof( D3DXVECTOR3 ) + sizeof( D3DXVECTOR3 ) + sizeof( D3DXMATRIX ) = 88 i think


class BadAssumptionError(Exception):
    pass


class Navigator:

    def __init__(self, whichGame: str, steam_gog: bool, file: bytes, nonconforming: set | None):
        self._whichGame, self._steam_gog, self._file, self._nonconforming = whichGame, steam_gog, file, nonconforming

        self._charEnchants = {"PASSIVE": [], "USAGE": []}
        self._items = {"EQUIPPED": [], "INVENTORY": []}

        self._pos = 0
        self._garbageUpTo = None #up to and including last btye of NUMBER OF ITEMS
        self._garbageResume = None

        self._execParse()


    #------------------------------------------------------------------------------------------------------------#
    # Public methods for querying.

    def items(self) -> dict["EQUIPPED", "INVENTORY"]:
        return self._items

    def charEnchants(self) -> dict["PASSIVE", "USAGE"]:
        return self._charEnchants

    def everythingBefore(self) -> bytes:
        return self._file[:self._garbageUpTo]

    def everythingAfter(self) -> bytes:
        return self._file[self._garbageResume:]


    #------------------------------------------------------------------------------------------------------------#
    # Methods for high-level navigation and reading.

    def _execParse(self) -> None:
        for n in range(self._goTilNumItems()):
            filler = self._parseItem()
            self._items["EQUIPPED" if filler[4] else "INVENTORY"].append(Item(filler)) #index 4 is equipped

        self._garbageResume = self._pos

    def _goTilNumItems(self) -> int:
        """Ret: number of items.
        Also writes self._charEnchants along the way."""

        if self._whichGame == "OG":
            self._move(7)
        else:
            self._move(15)

        for n in range(c.MAX_HOTKEYS):
            self._passThisString()

        self._move(c.CONTEXT_TIPS)   #funny how all games have the same num of these tips
        
        if self._whichGame in {"UR", "TS"}:     #UR CHANGE
            self._move(4)

        self._passThisString()
        self._passThisString()

        self._move(5)

        self._move((c.JOURNAL_STATISTICS + (1 if self._steam_gog else 0)) * 4)

        self._move(8 * 4)

        # ASSUMPTION
        if self._steam_gog and self._whichGame in {"UR", "TS"}:
            self._move(8)

        #character name is here
        self._passThisString()
        self._passThisString()

        self._move(191)
        #we should now just have passed m_Unique (line 11860)

        self._move(c.DAMAGE_TYPES * 4)  #SCIENCE in UR and probs TS the enum used here is still 8, same as OG
        self._move(c.SKILLS * 4)

        for n1 in range(c.MAGIC_SPHERES):
            for n2 in range(c.MAX_SPELLS_PER_SPHERE):
                self._passThisString()

        self._passThisString()

        self._move(44)
        #we should now just have passed m_Gold (line 11906)

        self._parseCharEnchants()

        numItems = self._readInt() 
        self._garbageUpTo = self._pos

        return numItems

    def _parseCharEnchants(self) -> None:
        """Call once in self._goTilNumItems() in the right place."""

        #storing oldWhichGame and setting to OG bc every game writes the character's enchants the same way
        oldWhichGame = self._whichGame
        self._whichGame = "OG"
        for key in self._charEnchants:
            for n in range(self._readInt()):
                self._charEnchants[key].append(Enchant(self._parseEnchant()))
        self._whichGame = oldWhichGame
    
    def _parseBonus(self) -> "filler for Bonus()":
        type = self._readInt()
        val = self._readInt()

        return (type, val)

    def _parseEnchant(self) -> "filler for Enchant()":

        urts_garbage1 = self._read(4) if self._whichGame == "TS" else b''

        name = self._passThisString(read = True)
        message = self._passThisString(read = True)

        exclusive = bool(self._readInt(1))
        type = self._readInt()
        damageType = self._readInt()
        positive = bool(self._readInt(1))
        activation = self._readInt()
        chanceOfSuccess = self._readInt()
        chanceOfSuccessBonus = self._readInt()
        chanceOfSuccessBonusPercent = self._readInt()
        duration = self._readInt()
        durationBonus = self._readInt() #stores it as a positive int but in the code a negative constant is used
        durationBonusPercent = self._readInt()
        value = self._readFloat()
        valueBonus = self._readFloat()
        valueBonusPercent = self._readFloat()
        value2 = self._readFloat()
        value2Bonus = self._readFloat()
        value2BonusPercent = self._readFloat()
        value3 = self._readFloat()
        value3Bonus = self._readFloat()
        value3BonusPercent = self._readFloat()
        priceMultiplier = self._readFloat()

        if self._whichGame == "TS":
            ts_beforeTypeStr = self._read(2)
            if ts_beforeTypeStr != b'\x00\x00':
                raise BadAssumptionError(f"Assumed 00 before enchant type string, got {weirdTwo}. ({self._pos - 2})")
            ts_typeStr = self._passThisString(read = True)
        else:
            ts_beforeTypeStr, ts_typeStr = b'', b''

        return (urts_garbage1,
                name,
                message,
                exclusive,
                type,
                damageType,
                positive,
                activation,
                chanceOfSuccess,
                chanceOfSuccessBonus,
                chanceOfSuccessBonusPercent,
                duration,
                durationBonus,
                durationBonusPercent,
                value,
                valueBonus,
                valueBonusPercent,
                value2,
                value2Bonus,
                value2BonusPercent,
                value3,
                value3Bonus,
                value3BonusPercent,
                priceMultiplier,
                ts_beforeTypeStr,
                ts_typeStr)

    def _parseItem(self) -> "filler for Item()":
        
        urts_garbage1 = self._read(4) if self._whichGame in {"UR", "TS"} else b''

        baseName = self._passThisString(read = True)

        fullName = self._passThisString(read = True)

        #cherry pick which i think are interesting

        slotIndex = self._readInt()

        equipped = bool(self._readInt(1))

        garbage1 = self._read(85)

        grade = self._readInt()

        garbage2 = self._read(3)

        armorBonus = self._readInt()

        sockets = self._readInt()

        #damage bonuses

        garbage3 = self._read(7)

        bonuses = [Bonus(self._parseBonus()) for _ in range(self._readInt())]

        ts_garbage2 = self._read(8) if self._whichGame == "TS" else b''

        if self._whichGame in {"OG", "UR"}:
            enchants = {"PASSIVE": [Enchant(self._parseEnchant()) for _ in range(self._readInt())],
                        "USAGE":   [Enchant(self._parseEnchant()) for _ in range(self._readInt())]}

            subItems = [Item(self._parseItem()) for _ in range(self._readInt())]

            #m_heroID (4) and m_HEROID.c_str() (1)
            ts_enchantGarbage, urts_ending = b'', b'' if self._whichGame == "OG" else self._read(4)

            if self._whichGame == "UR" and urts_ending !=  b'\x00\x00\x00\x00':
                raise BadAssumptionError(f"Assumed 0000 at end but got {urts_ending} ({self._pos - 4})")

        else:
            #nested sub items
            subItems = [Item(self._parseItem()) for _ in range(self._readInt())]

            ### ASSUMPTION that only one enchant key ("PASSIVE")

            if baseName in self._nonconforming:
                ts_enchantGarbage = self._read(12)
                if ts_enchantGarbage != b'\x00\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00':
                    raise BadAssumptionError(f"Assumed 0000 2000 0000 in enchants but got {ts_enchantGarbage}. ({self._pos - 12})")
            else:
                ts_enchantGarbage = self._read(8)
                if ts_enchantGarbage != b'\x00\x00\x00\x00\x02\x00\x00\x00':
                    raise BadAssumptionError(f"Assumed 0000 2000 in enchants but got {ts_enchantGarbage}. ({self._pos - 8})")

            enchants = {"PASSIVE": [Enchant(self._parseEnchant()) for _ in range(self._readInt())],
                        "USAGE":   []}

            expectedZeroes = 2 if baseName in self._nonconforming else 6
            urts_ending = self._read(expectedZeroes)

            if urts_ending != b'\x00' * expectedZeroes:
                raise BadAssumptionError(f"Assumed {expectedZeroes} zeroes at the end but got {urts_ending}. ({self._pos - expectedZeroes})")

        return (urts_garbage1,
                baseName,
                fullName, 
                slotIndex, 
                equipped, 
                garbage1, 
                grade, 
                garbage2, 
                armorBonus, 
                sockets, 
                garbage3,
                bonuses, 
                ts_garbage2,
                ts_enchantGarbage,
                enchants,
                subItems,
                urts_ending)


    #------------------------------------------------------------------------------------------------------------#
    # Methods for low-level bytes navigation and reading.

    def _move(self, by: int, rel = True) -> int:
        if rel:
            self._pos += by
        else:
            self._pos = by
        return self._pos

    def _read(self, size: int) -> bytes:
        toRet = self._file[self._pos:self._pos + size]
        self._pos += size
        return toRet

    def _passThisString(self, size: int = 2, read: bool = False) -> bytes | None:
        """Assumes pos is at the first byte of the string size.
        Ret: BYTES not string."""
        length = int.from_bytes(self._read(size), "little")

        if read:
            return self._read(length)
            
        self._move(length)

    def _readInt(self, size = 4) -> int:
        return int.from_bytes(self._read(size), "little")

    def _readFloat(self, size = 4) -> float:
        return struct.unpack('f', self._read(size))[0]


#------------------------------------------------------------------------------------------------------------#
# ts_findNonconforming() called in ui.getInitialInfo() for TS.

def ts_findNonconforming(gameDirStr: str) -> set:
    """Adds to _nonconforming all base item names that don't conform as bytes.
    Called only in ui.getInitialInfo() for TS."""

    nonconforming = set()
    # ASSUMPTION this is just a guess for what is nonconforming
    NONCONFOM = {"POTION",
	            "SCROLL",
	            "BOOK",
	            "SPELL",
	            "PETFOOD",
                "TAROT"}

    for ext in (r"\ITEMS\en-US\items.dat", r"\REALMS\Goldshare\ITEMS\en-us\items.dat", r"\REALMS\URGold\ITEMS\en-us\items.dat"):
        thisPath = gameDirStr + ext
        startsEnds = []
        start, end = None, None
        with open(thisPath) as rObj:
            lines = rObj.read().splitlines()
        for i, line in enumerate(lines):
            if line.startswith("[ITEM]"):
                start = i
            elif line.startswith("[/ITEM]"):
                end = i
            if start is not None and end is not None:
                startsEnds.append((start, end))
                start, end = None, None

        for start, end in startsEnds:
            the_name, the_type = None, None
            for i in range(start + 1, end + 1 - 1):
                if lines[i].startswith("<NAME>:"):
                    the_name = lines[i][7:]
                elif lines[i].startswith("<TYPE>:"):
                    the_type = lines[i][7:]
                if (the_name is not None and the_type is not None) or i == end - 1:
                    if the_type in NONCONFOM:
                        nonconforming.add(bytes(the_name, encoding = "utf-8"))
                        the_name, the_type = None, None
                    break
    
    return nonconforming