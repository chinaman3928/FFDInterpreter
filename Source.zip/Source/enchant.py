import struct
import c

class Enchant:
    
    def __init__(self, filler: tuple):
        """Can only be constructed by passing tuple of each attribute."""
        (self._urts_garbage1,
         self._name,
         self._message,
         self._exclusive,
         self._type,
         self._damageType,
         self._positive,
         self._activation,
         self._chanceOfSuccess,
         self._chanceOfSuccessBonus,
         self._chanceOfSuccessBonusPercent,
         self._duration,
         self._durationBonus,
         self._durationBonusPercent,
         self._value,
         self._valueBonus,
         self._valueBonusPercent,
         self._value2,
         self._value2Bonus,
         self._value2BonusPercent,
         self._value3,
         self._value3Bonus,
         self._value3BonusPercent,
         self._priceMultiplier,
         self._ts_beforeTypeStr,
         self._ts_typeStr) = filler

    def __repr__(self) -> str:
        return f"<{c.ENCHANTS_INT_STR[self._type]} ; {(self._value, self._value2, self._value3)} ; {self._positive}>"

    def type(self) -> int:
        return self._type

    def value(self) -> float:
        return self._value

    def ts_typeStr(self, decode = True) -> str | bytes:
        return self._ts_typeStr.decode("utf-8") if decode else self._ts_typeStr

    def setVal(self, new: int, positive: bool) -> None:
        if self._positive != positive:
            self._positive = positive
        self._value = new

    def getWrite(self) -> bytearray:
        toWrite = bytearray()

        toWrite += self._urts_garbage1

        toWrite += len(self._name).to_bytes(2, "little")
        toWrite += self._name

        toWrite += len(self._message).to_bytes(2, "little")
        toWrite += self._message

        toWrite += self._exclusive.to_bytes(1, "little")
        toWrite += self._type.to_bytes(4, "little")
        toWrite += self._damageType.to_bytes(4, "little")
        toWrite += self._positive.to_bytes(1, "little")

        for elem in (self._activation,
                     self._chanceOfSuccess,
                     self._chanceOfSuccessBonus,
                     self._chanceOfSuccessBonusPercent,
                     self._duration,
                     self._durationBonus,
                     self._durationBonusPercent):
            toWrite += elem.to_bytes(4, "little")

        for elem in (self._value,
                     self._valueBonus,
                     self._valueBonusPercent,
                     self._value2,
                     self._value2Bonus,
                     self._value2BonusPercent,
                     self._value3,
                     self._value3Bonus,
                     self._value3BonusPercent,
                     self._priceMultiplier):
            toWrite += struct.pack('f', elem)

        toWrite += self._ts_beforeTypeStr

        if self._ts_typeStr != b'':
            toWrite += len(self._ts_typeStr).to_bytes(2, "little")
            toWrite += self._ts_typeStr

        return toWrite

def makeNew(type: int, val: int, positive: bool) -> Enchant:
        filler = (b'',      #urts_garbage1
                  b'',		#name
                b'',		#message
                False,		#exclusive
                type,		#type
                3,			#damageType				ASSUMED
                positive,	#positive
                0,			#activation
                100,		#chanceOfSuccess
                0,			#chanceOfSuccessBonus
                0,			#chanceOfSuccessBonusPercent
                4294966296, #duration int32
                0,			#durationBonus
                0,			#durationBonusPercent
                val,		#value
                0,			#valueBonus
                0,			#valueBonusPercent
                0,			#value2
                0,			#value2Bonus
                0,			#value2BonusPercent
                0,			#value3
                0,			#value3Bonus
                0,			#value3BonusPercent
                0,			#priceMultiplier		YOU SURE YOU WANT 0?
                b'',        #ts_beforeTypeStr
                b'')        #ts_typeStr

        return Enchant(filler)